# Amazonia Store — Projeto acadêmico

Loja virtual demonstrativa criada com HTML5, CSS3 e JavaScript puro. Inclui layout responsivo, busca, filtros por categoria, ordenação por preço, carrinho com quantidades/subtotal, notificações e formulário demonstrativo de newsletter.

## Publicar no GitHub Pages
1. Crie um repositório público chamado `kaua-anderson` (ou outro nome com seu nome e sobrenome).
2. Envie os arquivos `index.html`, `style.css` e `script.js` para a raiz do repositório.
3. No GitHub, abra **Settings → Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**, branch `main` e pasta `/ (root)`, e salve.
5. Aguarde a publicação. O link será parecido com `https://SEU-USUARIO.github.io/kaua-anderson/`.
6. Abra o link em uma janela anônima para verificar que está público. Entregue somente esse link no AVA.

## Observação
Este é um projeto acadêmico demonstrativo, sem integração com pagamentos, contas ou pedidos reais. Os produtos e preços são fictícios.
